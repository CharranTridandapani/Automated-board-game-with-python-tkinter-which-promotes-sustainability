import os
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk


class ImageImporterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Image Importer App")

        self.image_path = None
        self.saved_image_path = None

        # Input fields for user details
        self.name_var = tk.StringVar()
        self.blood_group_var = tk.StringVar()
        self.contact_number_var = tk.StringVar()

        self.name_label = tk.Label(self, text="Name:")
        self.name_label.pack()
        self.name_entry = tk.Entry(self, textvariable=self.name_var)
        self.name_entry.pack()

        self.blood_group_label = tk.Label(self, text="Blood Group:")
        self.blood_group_label.pack()
        self.blood_group_entry = tk.Entry(self, textvariable=self.blood_group_var)
        self.blood_group_entry.pack()

        self.contact_number_label = tk.Label(self, text="Contact Number:")
        self.contact_number_label.pack()
        self.contact_number_entry = tk.Entry(self, textvariable=self.contact_number_var)
        self.contact_number_entry.pack()

        self.import_button = tk.Button(self, text="Import Image", command=self.import_image)
        self.import_button.pack(pady=10)

        self.display_button = tk.Button(self, text="Display Result", command=self.display_result, state=tk.DISABLED)
        self.display_button.pack(pady=10)

    def import_image(self):
        initial_dir = "/Users/venu/Desktop/CDP"
        self.image_path = filedialog.askopenfilename(title="Select Image File",
                                                     initialdir=initial_dir,
                                                     filetypes=(("Image Files", "*.jpg *.png"),))
        if self.image_path:
            self.save_image()
            self.display_button.config(state=tk.NORMAL)

    def save_image(self):
        save_folder = r"C:\Users\Abc\Downloads\Brain-Tumor-Detection-master\Brain-Tumor-Detection-master\venu"
        if not os.path.exists(save_folder):
            os.makedirs(save_folder)

        self.saved_image_path = os.path.join(save_folder, "saved_image.png")
        try:
            image = Image.open(self.image_path)
            image.save(self.saved_image_path)
        except Exception as e:
            tk.messagebox.showerror("Error", f"Failed to save image: {e}")

    def display_result(self):
        save_folder = r"C:\Users\Abc\Downloads\Brain-Tumor-Detection-master\Brain-Tumor-Detection-master\venu"
        self.saved_image_path = os.path.join(save_folder, "saved_image.png")

        if os.path.exists(save_folder):
            display_window = tk.Toplevel(self)
            display_window.title("Display Result")

            # Display entered user details
            name_label = tk.Label(display_window, text="Name: " + self.name_var.get())
            name_label.pack()

            blood_group_label = tk.Label(display_window, text="Blood Group: " + self.blood_group_var.get())
            blood_group_label.pack()

            contact_number_label = tk.Label(display_window, text="Contact Number: " + self.contact_number_var.get())
            contact_number_label.pack()

            # Display the saved image
            saved_image = Image.open(self.saved_image_path)
            saved_photo = ImageTk.PhotoImage(saved_image)
            label = tk.Label(display_window, image=saved_photo)
            label.image = saved_photo
            label.pack(padx=10, pady=10)

            # Add a label to indicate "Cancer Detected"
            cancer_label = tk.Label(display_window, text="Cancer Detected informing health care center ", fg="red",
                                    font=("Helvetica", 16, "bold"))
            cancer_label.pack(pady=5)

            # Clear input fields after displaying the result
            self.clear_input_fields()
        else:
            messagebox.showerror("Error", f"No images found in {save_folder}. Please import and save images first.")

    def clear_input_fields(self):
        self.name_var.set("")
        self.blood_group_var.set("")
        self.contact_number_var.set("")


if __name__ == "__main__":
    app = ImageImporterApp()
    app.mainloop()
