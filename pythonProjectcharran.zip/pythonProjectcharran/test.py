import tkinter as tk
from tkinter import simpledialog, messagebox
import turtle
import random
import webbrowser

# Initialize the main Tkinter window
root = tk.Tk()
root.title("Board Game")

# Setup Turtle Screen
canvas = tk.Canvas(master=root, width=700, height=500)
canvas.pack()
t_screen = turtle.TurtleScreen(canvas)
t_screen.bgcolor("silver")

# Define questions and answers for each coordinate
questions_answers = {
    (0, 3): ("What is the capital of France?", ["Paris"]),
    (1, 1): ("What is the capital of Spain?", ["Madrid"]),
    (2, 2): ("What is 2+2?", ["4"]),
    (3, 4): ("What is the capital of Japan?", ["Tokyo"]),
    (4, 2): ("What is the capital of Italy?", ["Rome"]),
    (5, 5): ("What is the capital of India?", ["New Delhi"]),
    (6, 0): ("What is 6*7?", ["42"]),
}

# Define the boxes with video content and their corresponding URLs
video_boxes = {
    (0, 1): "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    (3, 0): "https://www.youtube.com/watch?v=oHg5SJYRHA0",
    (2, 0): "https://www.youtube.com/watch?v=Z9lg6HqJeY0",
}

# Define coordinates where recycling game needs to be played
recycling_challenge_boxes = [(1, 6), (3, 6), (5, 6), (6, 6), (5, 5), (4, 5), (2, 5), (0, 5),
                             (0, 4), (1, 4), (3, 4), (5, 4), (6, 3), (4, 3)]


# Function to handle Recycling Challenge mini-game
def recycling_challenge(player, roll):
    global timer_label

    messagebox.showinfo("Recycling Challenge", "Welcome to the Recycling Challenge!\n\n"
                                               "You have 30 seconds to sort recyclable items into the appropriate bins.\n"
                                               "Click on the item to move it to the bin.\n"
                                               "Green bin: Paper\n"
                                               "Blue bin: Plastic\n"
                                               "Brown bin: Glass\n"
                                               "Yellow bin: Metal")

    # Create the canvas for the mini-game
    mini_game_window = tk.Toplevel(root)
    mini_game_window.title("Recycling Challenge")

    recycling_canvas = tk.Canvas(mini_game_window, width=700, height=500)
    recycling_canvas.pack()

    # Initialize variables
    bins = {"Paper": [], "Plastic": [], "Glass": [], "Metal": []}
    items = ["Paper", "Plastic", "Glass", "Metal"]
    item_objects = []

    # Function to handle item drag and drop
    def drag_start(event):
        item = event.widget.find_closest(event.x, event.y)[0]
        event.widget.drag_data = {"item": item, "x": event.x, "y": event.y}

    def drag_motion(event):
        data = event.widget.drag_data
        delta_x = event.x - data["x"]
        delta_y = event.y - data["y"]
        event.widget.move(data["item"], delta_x, delta_y)
        data["x"] = event.x
        data["y"] = event.y

    def drag_end(event):
        item = event.widget.find_closest(event.x, event.y)[0]
        item_name = event.widget.gettags(item)[0]
        item_position = event.widget.coords(item)
        for bin_name, bin_coords in bins.items():
            if item_position[0] >= bin_coords[0] and item_position[1] >= bin_coords[1] \
                    and item_position[0] <= bin_coords[2] and item_position[1] <= bin_coords[3]:
                if item_name.lower() == bin_name.lower():
                    messagebox.showinfo("Correct", f"You placed {item_name} in the correct bin!")
                    event.widget.delete(item)
                    items.remove(item_name)
                    if not items:
                        handle_success()  # Move the player after the game is completed
                        mini_game_window.destroy()  # Destroy the window when all items are sorted correctly
                        return
                return
        messagebox.showerror("Error", "Please drop the item in one of the bins.")

    bin_positions = {
        "Paper": (50, 50, 150, 150),  # Green
        "Plastic": (200, 50, 300, 150),  # Blue
        "Glass": (350, 50, 450, 150),  # Brown
        "Metal": (500, 50, 600, 150)  # Yellow
    }

    bin_colors = {
        "Paper": "green",
        "Plastic": "blue",
        "Glass": "brown",
        "Metal": "yellow"
    }

    bin_labels = {
        "Paper": "Paper Bin",
        "Plastic": "Plastic Bin",
        "Glass": "Glass Bin",
        "Metal": "Metal Bin"
    }

    for bin_name, coords in bin_positions.items():
        recycling_canvas.create_rectangle(coords, fill=bin_colors[bin_name],
                                          outline="black")
        bins[bin_name] = coords
        x_center = (coords[0] + coords[2]) / 2
        y_center = (coords[1] + coords[3]) / 2
        recycling_canvas.create_text(x_center, y_center, text=bin_labels[bin_name], font=("Arial", 10), fill="black")

    # Place items
    for item in items:
        x = random.randint(50, 650)
        y = random.randint(250, 450)
        item_obj = recycling_canvas.create_text(x, y, text=item, fill="black", font=("Arial", 12), tags=item)
        item_objects.append(item_obj)
        recycling_canvas.tag_bind(item_obj, "<ButtonPress-1>", drag_start)
        recycling_canvas.tag_bind(item_obj, "<B1-Motion>", drag_motion)
        recycling_canvas.tag_bind(item_obj, "<ButtonRelease-1>", drag_end)

    # Start countdown timer for recycling challenge
    seconds_left = 30

    def countdown():
        nonlocal seconds_left
        if seconds_left == 0:
            messagebox.showinfo("Time's Up!", "Time's up! Please try again.")
            messagebox.showinfo("Next Turn", "You will move on your next turn.")
            mini_game_window.destroy()
            return
        else:
            seconds_left -= 1
            timer_label.config(text=f"Time left: {seconds_left} seconds")
            mini_game_window.after(1000, countdown)

    timer_label = tk.Label(mini_game_window, text=f"Time left: {seconds_left} seconds", font=("Arial", 14))
    timer_label.pack()
    countdown()


# Function to handle success after completing the mini-game
def handle_success():
    global current_player
    current_index = current_player.move_sequence.index(current_player.current_row_col)
    next_index = current_index + current_player.last_roll
    if next_index < len(current_player.move_sequence):
        next_position = current_player.move_sequence[next_index]
        if next_position in recycling_challenge_boxes:
            recycling_challenge(current_player, current_player.last_roll)
        elif next_position in questions_answers:
            handle_question(current_player, next_position)
        elif next_position in video_boxes:
            show_video_popup(*next_position)
            current_player.goto(current_player.calculate_position(next_position))
            current_player.current_row_col = next_position
        else:
            current_player.goto(current_player.calculate_position(next_position))
            current_player.current_row_col = next_position

        if next_position == (3, 3):
            messagebox.showinfo("Congratulations!", f"Player {current_player.color} reached the finish line. "
                                                      f"Player {current_player.color} wins!")
            root.quit()  # End the game if a player reaches the finish line
    else:
        messagebox.showinfo("Game Over", "The game is over. No more moves remaining.")

# Function to handle questions
def handle_question(player, next_position):
    question, choices = questions_answers[next_position]
    user_answer = simpledialog.askstring("Question", question + "\n\nChoices:\n" + ", ".join(choices), parent=root)
    if user_answer and user_answer.lower() in [choice.lower() for choice in choices]:
        messagebox.showinfo("Correct", "You answered correctly! Moving forward.")
        player.goto(player.calculate_position(next_position))
        player.current_row_col = next_position
    else:
        correct_answer = [choice for choice in choices if choice.lower() == questions_answers[next_position][1][0].lower()][0]
        messagebox.showinfo("Incorrect", f"Sorry, '{user_answer}' is incorrect. The correct answer is '{correct_answer}'. "
                                          "You stay at the same position.")

# Function to handle video pop-ups
def show_video_popup(row, col):
    if (row, col) in video_boxes:
        video_url = video_boxes[(row, col)]
        webbrowser.open(video_url)

# Define move sequences for players
move_sequence_blue = [
    (0, 6), (1, 6), (2, 6), (3, 6), (4, 6), (5, 6), (6, 6), (6, 5), (5, 5), (4, 5), (3, 5), (2, 5), (1, 5), (0, 5),
    (0, 4), (1, 4), (2, 4), (3, 4), (4, 4), (5, 4), (6, 4), (6, 3), (5, 3), (4, 3), (3, 3)
]

move_sequence_red = [
    (6, 0), (5, 0), (4, 0), (3, 0), (2, 0), (1, 0), (0, 0), (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1),
    (6, 1), (6, 2), (5, 2), (4, 2), (3, 2), (2, 2), (1, 2), (0, 2), (0, 3), (1, 3), (2, 3), (3, 3)
]

# Player class to manage player movements and positions
class Player(turtle.RawTurtle):
    # Initialize with move sequence
    def __init__(self, shape, color, start_row_col, move_sequence):
        super().__init__(t_screen, shape=shape)
        self.penup()
        self.color(color)
        self.start_row_col = start_row_col
        self.goto(self.calculate_position(start_row_col))
        self.current_row_col = start_row_col
        self.move_sequence = move_sequence
        self.last_roll = 0

    def move(self, steps):
        current_index = self.move_sequence.index(self.current_row_col)
        next_index = current_index + steps
        max_index = len(self.move_sequence) - 1

        # Check if steps exceed the remaining path to the end
        if next_index > max_index:
            messagebox.showinfo("Cannot Move", "Roll exceeds steps needed to reach the end. Wait for next turn.")
            return

        next_position = self.move_sequence[next_index]

        if next_position in recycling_challenge_boxes:
            recycling_challenge(self, steps)
        elif next_position in questions_answers:
            handle_question(self, next_position)
        elif next_position in video_boxes:
            show_video_popup(*next_position)
            self.goto(self.calculate_position(next_position))
            self.current_row_col = next_position
        else:
            self.goto(self.calculate_position(next_position))
            self.current_row_col = next_position

        if next_index == len(self.move_sequence) - 1:
            return

        self.last_roll = steps

    def calculate_position(self, row_col):
        x = -150 + row_col[0] * 50 + 25
        y = 150 - row_col[1] * 50 - 25
        return (x, y)

# Draw the board
def draw_board():
    board_turtle = turtle.RawTurtle(t_screen)
    board_turtle.speed(0)
    board_turtle.hideturtle()
    t_screen.tracer(0)

    for y in range(7):
        for x in range(7):
            if (x, y) == (3, 3):
                draw_box(board_turtle, x, y, special=True)
            else:
                draw_box(board_turtle, x, y)

    for i, position in enumerate(move_sequence_blue, start=1):
        if i != 25:
            x, y = position
            draw_number(board_turtle, x, y, i, "blue")

    for i, position in enumerate(move_sequence_red, start=1):
        if i != 25:
            x, y = position
            draw_number(board_turtle, x, y, i, "red")

    draw_start_text(board_turtle, 0, 6, "blue")
    draw_start_text(board_turtle, 6, 0, "red")

    t_screen.update()
    t_screen.tracer(1)

def draw_box(turtle_obj, x, y, special=False):
    turtle_obj.penup()
    start_x = -150 + x * 50
    start_y = 150 - y * 50
    turtle_obj.goto(start_x, start_y)
    turtle_obj.pendown()
    if special:
        turtle_obj.fillcolor("yellow")
        turtle_obj.begin_fill()
    for _ in range(4):
        turtle_obj.forward(50)
        turtle_obj.right(90)
    if special:
        turtle_obj.end_fill()
        turtle_obj.penup()
        turtle_obj.goto(start_x + 25, start_y - 20)
        turtle_obj.write("Finish", align="center", font=("Arial", 12, "bold"))

def draw_number(turtle_obj, x, y, number, color):
    turtle_obj.penup()
    turtle_obj.goto(-130 + x * 50, 160 - y * 50)
    turtle_obj.color(color)
    turtle_obj.write(number, align="center", font=("Arial", 12, "normal"))

def draw_start_text(turtle_obj, x, y, color):
    turtle_obj.penup()
    turtle_obj.goto(-130 + x * 50, 160 - y * 50)
    turtle_obj.color(color)
    turtle_obj.write("Start", align="center", font=("Arial", 12, "normal"))

# Function to handle roll button click
def roll_button_click():
    global current_player
    roll = random.randint(1, 6)
    messagebox.showinfo("Roll Dice", f"You rolled a {roll}!")
    current_player.move(roll)

# Create players
blue_player = Player("turtle", "blue", (0, 6), move_sequence_blue)
red_player = Player("turtle", "red", (6, 0), move_sequence_red)

# Draw the board
draw_board()

# Create Roll Dice button
roll_button = tk.Button(root, text="Roll Dice", command=roll_button_click)
roll_button.pack()

# Start the game
current_player = blue_player

# Run the Tkinter event loop
root.mainloop()
