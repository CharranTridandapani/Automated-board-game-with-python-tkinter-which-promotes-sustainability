import cv2
import numpy as np

def detect_brown(frame):
    # Convert BGR to HSV
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # Define range of brown color in HSV
    lower_brown = np.array([5, 50, 50])
    upper_brown = np.array([30, 255, 255])

    # Threshold the HSV image to get only brown colors
    mask = cv2.inRange(hsv, lower_brown, upper_brown)

    return mask

def detect_spots(frame, brown_mask):
    # Convert frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Blur the grayscale image
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Threshold the blurred image to create a binary mask
    _, thresh = cv2.threshold(blurred, 60, 255, cv2.THRESH_BINARY)

    # Combine threshold and brown mask to focus only on brown regions
    brown_thresh = cv2.bitwise_and(thresh, brown_mask)

    # Find contours of brown regions
    contours, _ = cv2.findContours(brown_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Filter contours based on area and closure
    filtered_contours = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        peri = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        if 500 < area < 5000 and len(approx) > 4:
            filtered_contours.append(cnt)

    # Draw contours around filtered regions
    cv2.drawContours(frame, filtered_contours, -1, (0, 0, 255), 2)
    # Add text indicating leaf spots
    cv2.putText(frame, 'Leaf Spots', (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    return frame

def main():
    # Initialize webcam
    cap = cv2.VideoCapture(1,cv2.CAP_DSHOW)

    while True:
        # Read frame from webcam
        ret, frame = cap.read()
        if not ret:
            break

        # Detect brown regions and get mask
        brown_mask = detect_brown(frame)

        # Detect spots on brown regions
        spots_detected = detect_spots(frame, brown_mask)

        # Display the resulting frame
        cv2.imshow('Brown Spots Detection', spots_detected)

        # Break the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the VideoCapture object and close the OpenCV window
    cap.release()
    cv2.destroyAllWindows()

if _name_ == "_main_":
    main()
